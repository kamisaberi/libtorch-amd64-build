#include <torch/csrc/python_headers.h>

namespace torch::_export {

void initExportBindings(PyObject* module);

} // namespace torch::_export
