#pragma once

#include <c10/core/InferenceMode.h>
#include <torch/csrc/Export.h>

namespace torch::autograd {

using InferenceMode = c10::InferenceMode;

}
