#pragma once

namespace torch::autograd::profiler::python_tracer {

void init();

}
