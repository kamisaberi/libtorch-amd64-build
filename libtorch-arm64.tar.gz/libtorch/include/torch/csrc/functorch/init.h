#include <Python.h>

namespace torch::functorch::impl {

void initFuncTorchBindings(PyObject* module);

}
