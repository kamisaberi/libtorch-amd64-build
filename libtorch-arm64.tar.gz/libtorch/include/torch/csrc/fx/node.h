#pragma once

#include <torch/csrc/python_headers.h>

bool NodeBase_init(PyObject* module);
bool NodeIter_init(PyObject* module);
