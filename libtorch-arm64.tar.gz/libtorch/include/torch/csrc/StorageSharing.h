#ifndef THP_STORAGE_SHARING_INC
#define THP_STORAGE_SHARING_INC

#include <Python.h>

PyMethodDef* THPStorage_getSharingMethods();

#endif
